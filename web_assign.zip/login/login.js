import fs from 'fs/promises';
import bcrypt from 'bcryptjs';

const USERS_FILE = './users.json';

export async function login(question) {
  console.clear();
  console.log(' User Login ');

  const email = await question('Please enter your email: ');
  const password = await question('Please enter your password: ');

  const users = await fetchUsers();
  const user = users.find((u) => u.email === email);

  if (!user) {
    console.log('\nNo user found with that email.');
    return null;
  }

  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) {
    console.log('\nIncorrect password.');
    return null;
  }

  console.log('\nLogin successful.');
  return user;
}

async function fetchUsers() {
  try {
    const data = await fs.readFile(USERS_FILE, 'utf8');
    return JSON.parse(data);
  } catch {
    await fs.writeFile(USERS_FILE, '[]');
    return [];
  }
}
