import readline from 'readline';
import { register } from './register.js';
import { login } from './login.js';
import { displayProfile } from './profile.js';

// Set up readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

// Promisify the readline question method
const question = (query) => new Promise((resolve) => rl.question(query, resolve));

(async function main() {
  while (true) {
    console.clear();
    console.log(' Simple User Authentication System ');
    console.log('1. Register');
    console.log('2. Login');
    console.log('3. Exit');

    const choice = await question('Please select an option: ');

    switch (choice) {
      case '1':
        await register(question);
        break;
      case '2':
        const user = await login(question);
        if (user) {
          await showMenu(question, user);
        }
        break;
      case '3':
        console.log('\nFarewell.');
        rl.close();
        process.exit(0);
      default:
        console.log('\nInvalid selection! Please try again.');
    }
    await question('\nPress Enter to continue...');
  }
})();

async function showMenu(question, user) {
  while (true) {
    console.clear();
    console.log(` Welcome, ${user.name} `);
    console.log('1. View Profile');
    console.log('2. Logout');
    console.log('3. Exit');

    const choice = await question('Please select an option: ');

    switch (choice) {
      case '1':
        await displayProfile(question, user);
        break;
      case '2':
        console.log('\nSuccessfully logged out.');
        return;
      case '3':
        console.log('\nFarewell.');
        rl.close();
        process.exit(0);
      default:
        console.log('\nInvalid option! Please try again.');
    }
    await question('\nPress Enter to continue...');
  }
}
